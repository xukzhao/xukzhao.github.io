<?php
// ===================================================================
// 核心函数库 (Core Functions Library)
// ===================================================================

// 设置 session cookie 的生命周期为 30 天
$cookie_lifetime = 30 * 24 * 60 * 60; // 30 天
// 判断当前是否通过 HTTPS 访问（兼容反向代理 / Cloudflare）
$is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    || (($_SERVER['SERVER_PORT'] ?? '') == 443);
session_set_cookie_params([
    'lifetime' => $cookie_lifetime,
    'path' => '/',
    'httponly' => true,
    'samesite' => 'Lax',
    'secure' => $is_https,
]);
session_start();

// 引入安全优化
if (file_exists(__DIR__ . '/security_optimized.php')) {
    require_once __DIR__ . '/security_optimized.php';
}

// 引入性能优化
if (file_exists(__DIR__ . '/performance_optimized.php')) {
    require_once __DIR__ . '/performance_optimized.php';
}

// 引入优化数据库函数
if (file_exists(__DIR__ . '/optimized_db_functions.php')) {
    require_once __DIR__ . '/optimized_db_functions.php';
}

// ===================================================================
// 安全函数 (Security Functions)
// ===================================================================

/**
 * 获取当前的 CSRF Token，如果不存在则生成一个。
 * @return string CSRF Token.
 */
function getCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * 校验提交的 CSRF Token 是否有效。
 * @param string|null $token 从表单或请求头中获取的 Token。
 * @return bool Token 是否有效。
 */
function verifyCsrfToken($token) {
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    // 使用 hash_equals 防止时序攻击
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * 安全地过滤和验证用户输入
 * @param string $input 用户输入
 * @param string $type 输入类型（title, content, tag等）
 * @return string 过滤后的安全输入
 */
function sanitizeInput($input, $type = 'general') {
    if ($input === null) {
        return '';
    }

    $input = trim($input);

    switch ($type) {
        case 'title':
            // 标题限制长度，移除潜在危险字符
            $input = substr($input, 0, 200);
            $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
            break;

        case 'content':
            // 内容允许较长，但需要过滤HTML和潜在危险字符
            // 注意：Markdown解析后会处理HTML，所以这里需要谨慎
            $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
            break;

        case 'tag':
            // 标签只允许字母、数字、下划线和连字符
            $input = preg_replace('/[^a-zA-Z0-9_-]/', '', $input);
            $input = substr($input, 0, 50); // 限制标签长度
            break;

        default:
            // 默认处理
            $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
            break;
    }

    return $input;
}

// 检查是否已认证
function isAuthenticated() {
    return isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true;
}

// ===================================================================
// 数据库配置和连接 (Database Configuration and Connection)
// ===================================================================

// 数据目录
if (!defined('DATA_DIR')) {
    define('DATA_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'data');
}

// 确保数据目录存在
if (!is_dir(DATA_DIR)) {
    if (!@mkdir(DATA_DIR, 0775, true)) {
        die('错误：无法创建数据目录，请检查权限设置。');
    }
}

// 数据库文件
if (!defined('DB_FILE')) {
    define('DB_FILE', DATA_DIR . DIRECTORY_SEPARATOR . 'notes.db');
}

// 密码文件
if (!defined('PASSWORD_FILE')) {
    define('PASSWORD_FILE', DATA_DIR . DIRECTORY_SEPARATOR . '.password');
}

// 每页笔记数
if (!defined('NOTES_PER_PAGE')) {
    define('NOTES_PER_PAGE', 10);
}

// 最大搜索结果数
if (!defined('MAX_SEARCH_RESULTS')) {
    define('MAX_SEARCH_RESULTS', 100);
}

/**
 * 获取数据库连接
 * @return PDO 数据库连接对象
 */
function getDbConnection() {
    static $db = null;
    
    if ($db !== null) {
        return $db;
    }
    
    try {
        // 确保数据库文件存在
        if (!file_exists(DB_FILE)) {
            $dir = dirname(DB_FILE);
            if (!is_dir($dir)) {
                mkdir($dir, 0775, true);
            }
        }
        
        $db = new PDO('sqlite:' . DB_FILE);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $db->exec("PRAGMA journal_mode=WAL;");
        
        // 初始化数据库表（如果不存在）
        initDatabase($db);
        
        return $db;
    } catch (PDOException $e) {
        error_log("Database connection failed: " . $e->getMessage());
        die("数据库连接失败，请检查配置或联系管理员。");
    }
}

/**
 * 初始化数据库表结构
 * @param PDO $db 数据库连接对象
 */
function initDatabase($db) {
    try {
        // 创建笔记表
        $db->exec("
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                content TEXT NOT NULL,
                tags TEXT,
                is_private INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_updated TEXT NOT NULL,
                version INTEGER DEFAULT 1
            )
        ");
        
        // 为提高搜索性能添加索引
        $db->exec("CREATE INDEX IF NOT EXISTS idx_notes_updated_at ON notes(updated_at DESC)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_notes_is_private ON notes(is_private)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_notes_tags ON notes(tags)");
    } catch (PDOException $e) {
        error_log("Database initialization failed: " . $e->getMessage());
    }
}

// ===================================================================
// 笔记操作函数 (Note Operation Functions)
// ===================================================================

/**
 * 创建笔记
 * @param string $title 笔记标题
 * @param string $content 笔记内容
 * @param array $tags 标签数组
 * @param int $is_private 是否私密
 * @return bool 创建是否成功
 */
function createNote($title, $content, $tags, $is_private = 0) {
    $db = getDbConnection();
    try {
        $stmt = $db->prepare("
            INSERT INTO notes (title, content, tags, is_private, created_at, updated_at, last_updated, version) 
            VALUES (:title, :content, :tags, :is_private, :created_at, :updated_at, :last_updated, 1)
        ");
        $now = date('Y-m-d H:i:s');
        $result = $stmt->execute([
            ':title' => $title,
            ':content' => $content,
            ':tags' => json_encode($tags),
            ':is_private' => $is_private,
            ':created_at' => $now,
            ':updated_at' => $now,
            ':last_updated' => $now
        ]);
        
        return $result;
    } catch (PDOException $e) {
        // 如果 'last_updated' 或 'version' 等字段缺失，记录错误
        error_log("Error creating note: " . $e->getMessage());
        return false;
    }
}

/**
 * 更新笔记
 * @param int $id 笔记ID
 * @param string $title 笔记标题
 * @param string $content 笔记内容
 * @param array $tags 标签数组
 * @param int $is_private 是否私密
 * @param int $expected_version 期望的版本号
 * @return bool|string 更新是否成功，'conflict'表示冲突
 */
function updateNote($id, $title, $content, $tags, $is_private, $expected_version) {
    $db = getDbConnection();
    
    try {
        $stmt = $db->prepare("
            UPDATE notes
            SET 
                title = :title, 
                content = :content, 
                tags = :tags, 
                is_private = :is_private,
                updated_at = :updated_at, 
                last_updated = :last_updated,
                version = version + 1
            WHERE id = :id AND version = :expected_version
        ");

        $now = date('Y-m-d H:i:s');
        $stmt->execute([
            ':id' => $id,
            ':title' => $title,
            ':content' => $content,
            ':tags' => json_encode($tags),
            ':is_private' => $is_private,
            ':updated_at' => $now,
            ':last_updated' => $now,
            ':expected_version' => $expected_version
        ]);

        if ($stmt->rowCount() === 0) {
            $check_stmt = $db->prepare("SELECT version FROM notes WHERE id = :id");
            $check_stmt->execute(['id' => $id]);
            if ($check_stmt->fetch()) {
                return 'conflict'; // 笔记存在，版本冲突
            } else {
                return false; // 笔记不存在
            }
        }

        return true;
    } catch (PDOException $e) {
        error_log("Error updating note {$id}: " . $e->getMessage());
        return false;
    }
}

/**
 * 删除笔记
 * @param int $id 笔记ID
 * @return bool 删除是否成功
 */
function deleteNote($id) {
    try {
        $db = getDbConnection();
        $stmt = $db->prepare("DELETE FROM notes WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    } catch (PDOException $e) {
        error_log("Error deleting note {$id}: " . $e->getMessage());
        return false;
    }
}

/**
 * 根据ID获取笔记
 * @param int $id 笔记ID
 * @return array|null 笔记数据或null
 */
function getNoteById($id) {
    if (!is_numeric($id) || $id <= 0) {
        return null;
    }
    
    try {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT * FROM notes WHERE id = :id");
        $stmt->execute([':id' => (int)$id]);
        $note = $stmt->fetch();

        // 权限检查：如果笔记是私密的且用户未登录，则不允许查看
        if ($note && !empty($note['is_private']) && $note['is_private'] == 1 && !isAuthenticated()) {
            return null;
        }

        if ($note && !empty($note['tags'])) {
            $note['tags'] = json_decode($note['tags'], true);
        } elseif ($note) {
            $note['tags'] = [];
        }

        return $note;
    } catch (PDOException $e) {
        error_log("Error getting note by id {$id}: " . $e->getMessage());
        return null;
    }
}

/**
 * 获取笔记列表
 * @param string|null $tag 标签筛选
 * @param string|null $query 搜索关键词
 * @param int $limit 限制数量
 * @param int $offset 偏移量
 * @return array 笔记列表
 */
function getNotes($tag = null, $query = null, $limit = NOTES_PER_PAGE, $offset = 0) {
    try {
        $db = getDbConnection();
        
        // 改进：使用显式 JOIN
        $sql = "SELECT notes.* FROM notes";
        if ($tag) {
            $sql .= " CROSS JOIN json_each(notes.tags)";
        }
        
        $params = [];

        $conditions = [];
        if (!isAuthenticated()) {
            $conditions[] = "notes.is_private = 0";
        }
        if ($tag) {
            $conditions[] = "json_each.value = :tag";
            $params[':tag'] = $tag;
        }
        if ($query) {
            $conditions[] = "(notes.title LIKE :query OR notes.content LIKE :query)";
            $params[':query'] = '%' . $query . '%';
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(' AND ', $conditions);
        }

        $sql .= " ORDER BY notes.updated_at DESC";

        // 改进：使用 is_numeric 检查分页参数
        if (is_numeric($limit)) {
            // 添加结果数量限制
            $limit = min((int)$limit, MAX_SEARCH_RESULTS);
            $sql .= " LIMIT :limit OFFSET :offset";
        }
        
        $stmt = $db->prepare($sql);
        
        if (isset($params[':tag'])) {
            $stmt->bindValue(':tag', $params[':tag'], PDO::PARAM_STR);
        }
        if (isset($params[':query'])) {
            $stmt->bindValue(':query', $params[':query'], PDO::PARAM_STR);
        }

        // 改进：使用 is_numeric 检查分页参数
        if (is_numeric($limit)) {
            $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', (int) $offset, PDO::PARAM_INT);
        }
        
        // 添加查询超时限制，防止复杂查询影响性能
        // $stmt->setAttribute(PDO::ATTR_TIMEOUT, 5); // 5秒超时 - 已禁用，会导致部分驱动出错
        
        $stmt->execute();
        $notes = $stmt->fetchAll();

        foreach ($notes as &$note) {
            if (!empty($note['tags'])) {
                $note['tags'] = json_decode($note['tags'], true);
            } else {
                $note['tags'] = [];
            }
        }
        
        return $notes;
    } catch (PDOException $e) {
        error_log("Error getting notes: " . $e->getMessage());
        return [];
    }
}

/**
 * 获取笔记数量
 * @param string|null $tag 标签筛选
 * @param string|null $query 搜索关键词
 * @return int 笔记数量
 */
function getNotesCount($tag = null, $query = null) {
    try {
        $db = getDbConnection();
        // 改进：使用 COUNT(DISTINCT) 确保在 JOIN 后计数准确
        $sql = "SELECT COUNT(DISTINCT notes.id) FROM notes";
        $params = [];

        // 改进：使用显式 JOIN
        if ($tag) {
            $sql .= " CROSS JOIN json_each(notes.tags)";
        }

        $conditions = [];
        if (!isAuthenticated()) {
            $conditions[] = "notes.is_private = 0";
        }
        if ($tag) {
            $conditions[] = "json_each.value = :tag";
            $params[':tag'] = $tag;
        }
        if ($query) {
            $conditions[] = "(notes.title LIKE :query OR notes.content LIKE :query)";
            $params[':query'] = '%' . $query . '%';
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(' AND ', $conditions);
        }
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error getting notes count: " . $e->getMessage());
        return 0;
    }
}

/**
 * 获取所有唯一的标签
 * @return array 标签列表
 */
function getAllTags() {
    try {
        $db = getDbConnection();
        if (!isAuthenticated()) {
            $stmt = $db->query("SELECT DISTINCT value FROM notes, json_each(notes.tags) WHERE notes.is_private = 0 ORDER BY value ASC");
        } else {
            $stmt = $db->query("SELECT DISTINCT value FROM notes, json_each(notes.tags) ORDER BY value ASC");
        }
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        error_log("Error getting all tags: " . $e->getMessage());
        return [];
    }
}

// ===================================================================
// 备份和安全函数 (Backup and Security Functions)
// ===================================================================

/**
 * 实现定期数据库备份功能，保留最近10个备份
 * @return string|bool 备份文件路径或false
 */
function createBackup() {
    $backupDir = DATA_DIR . DIRECTORY_SEPARATOR . 'backups';
    if (!is_dir($backupDir)) {
        if (!@mkdir($backupDir, 0775, true)) {
            error_log("Failed to create backup directory: {$backupDir}");
            return false;
        }
    }

    $backupFile = $backupDir . DIRECTORY_SEPARATOR . 'notes-backup-' . date('Y-m-d-H-i-s') . '.sqlite3';
    
    try {
        if (copy(DB_FILE, $backupFile)) {
            // 清理旧备份，只保留最近10个
            cleanupOldBackups($backupDir, 10);
            
            // 可选：记录备份成功日志
            // error_log("Successfully created backup: {$backupFile}");
            return $backupFile;
        } else {
            error_log("Failed to copy database for backup. Source: " . DB_FILE . ", Dest: " . $backupFile);
            return false;
        }
    } catch (Exception $e) {
        error_log("Exception during backup: " . $e->getMessage());
        return false;
    }
}

/**
 * 清理旧备份文件
 * @param string $backupDir 备份目录
 * @param int $keepCount 保留数量
 */
function cleanupOldBackups($backupDir, $keepCount) {
    // 匹配所有备份文件（createBackup 生成的是 notes-backup-*.sqlite3）
    $files = glob($backupDir . DIRECTORY_SEPARATOR . 'notes-backup-*');
    
    if (count($files) > $keepCount) {
        // 按修改时间排序
        usort($files, function($a, $b) {
            return filemtime($a) <=> filemtime($b);
        });
        
        // 删除最旧的文件，只保留指定数量
        $filesToDelete = array_slice($files, 0, count($files) - $keepCount);
        foreach ($filesToDelete as $file) {
            unlink($file);
        }
    }
}

/**
 * 获取存储的密码哈希
 * @return string 密码哈希
 */
function getPassword() {
    if (!file_exists(PASSWORD_FILE)) {
        return ''; // 如果文件不存在，返回空字符串
    }
    $hash = trim(file_get_contents(PASSWORD_FILE));

    // 检查是否是旧版本的明文密码（迁移用）
    if (strlen($hash) < 60) { // password_hash 生成的哈希通常超过60字符
        // 如果是明文密码，则哈希并保存
        $newHash = password_hash($hash, PASSWORD_DEFAULT);
        if (file_put_contents(PASSWORD_FILE, $newHash) !== false) {
            return $newHash;
        }
    }

    return $hash;
}

/**
 * 验证提交的密码是否与存储的哈希匹配。
 * @param string $submittedPassword 用户通过表单提交的原始密码。
 * @return bool 密码是否正确。
 */
function verifyPassword($submittedPassword) {
    $hash = getPassword();
    if (empty($hash) || empty($submittedPassword)) {
        return false;
    }
    return password_verify($submittedPassword, $hash);
}

// ===================================================================
// Markdown解析函数 (Markdown Parsing Functions)
// ===================================================================

// Markdown 解析
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

/**
 * 解析Markdown文本
 * @param string $text Markdown文本
 * @return string HTML内容
 */
function parseMarkdown($text) {
    static $engine = null;
    static $mode = null;

    if ($engine === null) {
        if (class_exists('League\CommonMark\GithubFlavoredMarkdownConverter')) {
            $engine = new League\CommonMark\GithubFlavoredMarkdownConverter([
                'html_input' => 'strip',
                'allow_unsafe_links' => false,
            ]);
            $mode = 'league';
        } elseif (class_exists('League\CommonMark\CommonMarkConverter')) {
            $engine = new League\CommonMark\CommonMarkConverter([
                'html_input' => 'strip',
                'allow_unsafe_links' => false,
            ]);
            $mode = 'league';
        } else {
            if (!class_exists('ParsedownExtra')) {
                $parsedown_path = __DIR__ . '/libs/Parsedown.php';
                $parsedown_extra_path = __DIR__ . '/libs/ParsedownExtra.php';

                if (!file_exists($parsedown_path) || !file_exists($parsedown_extra_path)) {
                    // Log the error and fallback to a simple text-to-html conversion
                    error_log("Markdown parser fallback failed: Parsedown library files not found in /libs directory.");
                    // Return plain text wrapped in <pre> to prevent raw HTML injection and preserve formatting
                    return '<pre>' . htmlspecialchars($text) . '</pre>';
                }
                // 使用 require_once 避免重复加载
                require_once $parsedown_path;
                require_once $parsedown_extra_path;
            }
            $engine = new ParsedownExtra();
            if (method_exists($engine, 'setSafeMode')) $engine->setSafeMode(true);
            if (method_exists($engine, 'setBreaksEnabled')) $engine->setBreaksEnabled(true);
            $mode = 'parsedown';
        }
    }

    if ($mode === 'league') {
        if (method_exists($engine, 'convert')) {
            return (string) $engine->convert($text);
        }
        if (method_exists($engine, 'convertToHtml')) {
            return $engine->convertToHtml($text);
        }
    }

    return $engine->text($text);
}

// ===================================================================
// 请求频率限制函数 (Rate Limiting Functions)
// ===================================================================

/**
 * 请求频率限制
 * @param string $action 操作类型
 * @return bool 是否允许执行
 */
function checkRateLimit($action) {
    $key = 'rate_limit_' . $_SERVER['REMOTE_ADDR'] . '_' . $action;
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = ['count' => 0, 'time' => time()];
    }

    if (time() - $_SESSION[$key]['time'] > 3600) {
        $_SESSION[$key] = ['count' => 0, 'time' => time()];
    }

    $_SESSION[$key]['count']++;

    $limit = ($action === 'login') ? 10 : 30;

    return $_SESSION[$key]['count'] <= $limit;
}