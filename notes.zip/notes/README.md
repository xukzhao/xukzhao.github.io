# 轻量级在线笔记本

> 一个使用 PHP 和 SQLite 构建的、简单快速、易于部署的在线笔记应用。

这是一个纯粹的、自托管的笔记解决方案，让您无需依赖任何第三方服务，即可拥有一个完全属于自己的在线笔记空间。它非常适合部署在个人服务器或虚拟主机上。

## ✨ 主要功能

- **📝 Markdown 优先**: 使用标准的 Github-Flavored Markdown 语法编写笔记，支持代码高亮、表格、任务列表等，并提供实时预览功能。
- **🏷️ 标签系统**: 通过为笔记添加多个标签来进行分类和筛选，方便管理和查找。
- **🔍 高效搜索**: 内置全文搜索功能，可以快速在所有笔记的标题和内容中查找关键词。
- **🔒 私密笔记**: 可以将单篇笔记设为私密，只有在登录状态下才对您可见。
- **🌙 明暗主题**: 支持手动切换日间/夜间模式，并能根据您的操作系统设置自动适配，有效防止页面加载时的“主题闪烁”问题。
- **🖼️ 文件上传**: 支持上传图片等附件，方便在笔记中引用和管理。
- **🖱️ 无限滚动**: 在笔记列表页，当您滚动到页面底部时，会自动加载更多内容，无需手动翻页。
- **🔐 安全可靠**: 
    - 内置 CSRF 防护机制。
    - 使用 PHP 预处理语句从根源上防止 SQL 注入攻击。
    - 通过 `DOMPurify` 对渲染的 HTML 进行严格过滤，有效防御 XSS 跨站脚本攻击。

## 🛠️ 技术栈

- **后端**: PHP 7.4+ 
- **数据库**: SQLite 3
- **前端**: 原生 JavaScript (ES6+), CSS3
- **核心依赖**: 
    - `Parsedown` / `league/commonmark`: 用于 Markdown 的服务端解析。

---

## 🚀 开始使用

### 1. 环境要求

- 一个支持 PHP 的 Web 服务器 (例如 Apache, Nginx, Caddy)。
- PHP 版本 >= 7.4。
- 已在 PHP 中启用 `sqlite3` 和 `pdo_sqlite` 扩展。

### 2. 安装步骤

1.  **下载代码**
    将本项目的所有文件下载或通过 Git 克隆到您的服务器网站根目录。

2.  **设置目录权限**
    为了让程序能正常写入数据和上传文件，请确保服务器对以下两个目录拥有写入权限：
    - `data/`
    - `uploads/`

    在 Linux/macOS 系统上，您可以通过以下命令设置权限：
    ```bash
    chmod -R 755 data
    chmod -R 755 uploads
    ```
    *根据您的服务器配置，所有者可能需要是 `www-data` 或其他用户。*

---

## ⚙️ 配置说明

### 1. 设置管理员密码

首次访问应用时，如果尚未设置密码，页面会直接显示「首次使用，请设置密码」，输入并确认两次即可（**推荐方式**）。

也可以手动设置：在 `data/` 目录下创建一个名为 `.password` 的文本文件（以点开头），写入你的原始密码（例如 `MySecretPassword123`）。首次访问时系统会自动读取并用 `password_hash` 加密，把哈希值写回 `data/.password`。

**请注意**: `data/.password` 中最终存储的是加密后的哈希值。后续登录验证只使用此文件，无法通过直接编辑它来更改密码。如需重置密码，请删除 `data/.password`，然后重新访问应用进行设置。

---

## � 部署到 VPS（Nginx / 与 WordPress 共存）

以下步骤以「服务器上已装好 WordPress + Nginx + PHP 8.2-FPM（运行用户为 `www-data`）」为例，把本应用作为一个子目录与 WordPress 共存。

> 本文示例：WordPress 站点根为 `/var/www/example.com`，域名为 `example.com`，应用放在 `/var/www/example.com/notes/`，访问地址为 `https://example.com/notes/`。
> 若路径 / 域名 / PHP 版本不同，请自行替换。

### 1. 上传文件

把应用放到站点根的子目录，例如：

```
/var/www/example.com/notes/
```

⚠️ **不要**放进 `wp-content/`、`wp-admin/`、`wp-includes/`——WordPress 的 Nginx 配置会拒绝在这些目录里执行 PHP。

### 2. 安装 SQLite 扩展（必做）

WordPress 使用 MySQL，服务器通常没装 SQLite 驱动。不装会报「数据库连接失败，请检查配置或联系管理员」，其真实错误是 `could not find driver`。

```bash
apt update
apt install php8.2-sqlite3      # 版本号改成你实际的 PHP 版本
systemctl restart php8.2-fpm

# 验证，应出现 pdo_sqlite 和 sqlite3 两行
php -m | grep -i sqlite
```

### 3. 设置目录权限

`data/` 和 `uploads/` 需要可写：

```bash
chown -R www-data:www-data /var/www/example.com/notes
chmod -R 755 /var/www/example.com/notes
chmod -R 775 /var/www/example.com/notes/data
chmod -R 775 /var/www/example.com/notes/uploads

# 确认 PHP-FPM 的运行用户
grep -E "^user" /etc/php/8.2/fpm/pool.d/www.conf
```

### 4. 配置 Nginx（安全关键）

在站点的 `server { }` 块内、WordPress 自己的 `location` 规则**之前**加入：

```nginx
# 屏蔽应用的敏感目录与文件（防止数据库/密码被下载）
location ~ ^/notes/(data|libs)/ { deny all; return 404; }
location ~ ^/notes/\.(password|env)$ { deny all; return 404; }

# 保证 /notes/ 目录能正确进入首页
location /notes/ {
    index index.php;
    try_files $uri $uri/ /notes/index.php?$args;
}
```

校验并重载：

```bash
nginx -t && systemctl reload nginx
```

> PHP 执行无需额外配置，WordPress 已有的 `location ~ \.php$ { fastcgi_pass ... }` 会一并处理。

### 5. 首次访问并设置密码

浏览器打开 `https://example.com/notes/`，因为没有密码文件，页面会显示「首次使用，请设置密码」，设置即可。之后 `data/` 下会自动生成 `notes.db` 和密码哈希文件。

### 6. 验收检查

- 首页能打开、能新建一条笔记；
- `data/notes.db` 已生成；
- **安全验证**：访问 `https://example.com/notes/data/notes.db` 应返回 **404**（而不是下载文件）。

### 常见问题速查

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 「数据库连接失败，请检查配置或联系管理员」，日志含 `could not find driver` | 缺 `pdo_sqlite` 扩展 | 见第 2 步 |
| 日志报权限错误 / 无法写入 | `data/` 不可写 | 见第 3 步 |
| `/notes/` 返回 WordPress 的 404 | `try_files` 未放行目录 | 见第 4 步的 `location /notes/` |
| PHP 文件返回 403/404 | 放在了 `wp-content` 等目录 | 移到站点根下的独立子目录 |
| 访问 `/notes/data/notes.db` 触发下载 | 未加 deny 规则 | 见第 4 步（安全风险，务必修复） |

> 排错统一查看 Nginx 错误日志：`tail -n 50 /var/log/nginx/error.log`

---

## �📖 使用方法

- **创建笔记**: 点击首页的“新建笔记”按钮，或使用主页上方的快速记录框。
- **编辑/删除**: 在文章列表页面，每个笔记卡片的右上角都有一个“三点”菜单，点击即可找到“编辑”和“删除”选项。
- **搜索笔记**: 使用首页顶部的搜索框进行全文搜索。
- **标签筛选**: 点击笔记下方的标签，即可查看所有包含该标签的笔记。
- **切换主题**: 点击页面上方的 🌙 / ☀️ 图标即可在明暗模式间切换。
