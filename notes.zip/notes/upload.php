<?php
// Image upload endpoint for Toast UI Editor
require_once __DIR__ . '/app_functions.php';

header('Content-Type: application/json; charset=utf-8');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// Require authentication (editing already requires auth)
if (!isAuthenticated()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// CSRF check: accept from header or form field
$csrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
if (!hash_equals($_SESSION['csrf_token'] ?? '', $csrfToken)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid CSRF token']);
    exit;
}

// Validate file presence
$fieldName = null;
foreach (['image', 'file', 'upload', 'imageFile'] as $name) {
    if (isset($_FILES[$name])) { $fieldName = $name; break; }
}
if (!$fieldName) {
    http_response_code(400);
    echo json_encode(['error' => 'No file uploaded']);
    exit;
}

$file = $_FILES[$fieldName];
if (!empty($file['error'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Upload error', 'code' => $file['error']]);
    exit;
}

// Security checks
$allowedMime = [
    'image/png' => 'png',
    'image/jpeg' => 'jpg',
    'image/jpg' => 'jpg',
    'image/gif' => 'gif',
    'image/webp' => 'webp',
];

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($file['tmp_name']);
if (!isset($allowedMime[$mime])) {
    http_response_code(400);
    echo json_encode(['error' => 'Unsupported file type', 'mime' => $mime]);
    exit;
}

$maxSize = 8 * 1024 * 1024; // 8MB
if ($file['size'] > $maxSize) {
    http_response_code(400);
    echo json_encode(['error' => 'File too large']);
    exit;
}

// Prepare upload directory
$uploadDir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';
if (!is_dir($uploadDir)) {
    if (!@mkdir($uploadDir, 0775, true)) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to create upload directory']);
        exit;
    }
}

// Generate safe filename
$ext = $allowedMime[$mime];
$base = bin2hex(random_bytes(8)) . '-' . date('YmdHis');
$filename = $base . '.' . $ext;
$target = $uploadDir . DIRECTORY_SEPARATOR . $filename;

// Move uploaded file
if (!move_uploaded_file($file['tmp_name'], $target)) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to save file']);
    exit;
}

// Optional: restrict permissions
@chmod($target, 0664);

// Build URL relative to this app root
$url = 'uploads/' . $filename;

echo json_encode(['url' => $url, 'status' => 'ok']);
