<?php
require_once 'app_functions.php';

// Ensure CSRF token is always available
getCsrfToken();

// ===================================================================
// POST Request Handling
// ===================================================================
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Protection
    $csrf_token = $_POST['csrf_token'] ?? '';
    $session_csrf_token = $_SESSION['csrf_token'] ?? '';
    if (!isset($_POST['csrf_token']) || !hash_equals($session_csrf_token, $csrf_token)) {
        $error = '无效的请求，请刷新页面后重试。';
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'create':
                if (!checkRateLimit('create')) {
                    $error = '您的操作过于频繁，请稍后再试。';
                    break;
                }
                $title = trim($_POST['title'] ?? '');
                $noteContent = $_POST['content'] ?? '';
                $tagsRaw = $_POST['tags'] ?? '';
                $is_private = (isAuthenticated() && isset($_POST['is_private'])) ? 1 : 0;
                
                if (trim($noteContent) !== '') {
                    $tags = array_values(array_filter(array_map('trim', explode(',', $tagsRaw))));
                    if (createNote($title, $noteContent, $tags, $is_private)) {
                        header('Location: index.php');
                        exit;
                    } else {
                        $error = '错误：无法创建笔记。请检查您的输入或稍后重试。';
                    }
                } else {
                    $error = '错误：笔记内容不能为空。';
                }
                break;
                
            case 'update':
                if (isAuthenticated()) {
                    $id = $_POST['id'] ?? 0;
                    $title = trim($_POST['title'] ?? '');
                    $noteContent = $_POST['content'] ?? '';
                    $tagsRaw = $_POST['tags'] ?? '';
                    $version = $_POST['version'] ?? 0;
                    $is_private = (isAuthenticated() && isset($_POST['is_private'])) ? 1 : 0;

                    if ($id && trim($noteContent) !== '') {
                        $tags = array_values(array_filter(array_map('trim', explode(',', $tagsRaw))));
                        $result = updateNote($id, $title, $noteContent, $tags, $is_private, $version);

                        if ($result === true) {
                            header('Location: index.php');
                            exit;
                        } elseif ($result === 'conflict') {
                            $error = '保存失败！在您编辑期间，这篇笔记已被其他进程修改。请查看最新内容，手动合并您的修改后再次保存。';
                            // Reload the note with the latest content and version to show the user
                            $note = getNoteById($id);
                            // Set action to 'edit' to re-render the edit form
                            $_GET['action'] = 'edit'; 
                        } else {
                            $error = '错误：无法更新笔记。请检查您的输入或稍后重试。';
                            // Reload the note with the latest content and version to show the user
                            $note = getNoteById($id);
                            // Set action to 'edit' to re-render the edit form
                            $_GET['action'] = 'edit';
                        }
                    } else {
                        $error = '错误：笔记ID或内容不能为空。';
                        // Reload the note with the latest content and version to show the user
                        $note = getNoteById($id);
                        // Set action to 'edit' to re-render the edit form
                        $_GET['action'] = 'edit';
                    }
                }
                break;
                
            case 'delete':
                if (isAuthenticated()) {
                    $id = $_POST['id'] ?? 0;
                    if ($id) {
                        if (deleteNote($id)) {
                            header('Location: index.php');
                            exit;
                        } else {
                            $error = '错误：无法删除笔记。请稍后重试。';
                        }
                    } else {
                        $error = '错误：无效的笔记ID。';
                    }
                }
                break;
                
            case 'login':
                if (!checkRateLimit('login')) {
                    $error = '登录尝试过于频繁，请稍后再试。';
                    $_GET['action'] = 'login'; // To show login form again
                    break;
                }
                $password = $_POST['password'] ?? '';
                $hash = getPassword();
                if ($hash && password_verify($password, $hash)) {
                    session_regenerate_id(true); // 防止会话固定攻击
                    $_SESSION['authenticated'] = true;
                    header('Location: index.php');
                    exit;
                } else {
                    $error = '密码错误或用户不存在';
                    $_GET['action'] = 'login'; // To show login form again
                }
                break;
                
            case 'logout':
                unset($_SESSION['authenticated']);
                header('Location: index.php');
                exit;
                
            case 'set_password':
                // 仅在尚未设置密码时允许设置，防止已有密码被覆盖（账号接管）
                if (getPassword() !== '') {
                    $error = '密码已设置。如需重置，请先删除 data/.password 文件后重试。';
                    $_GET['action'] = 'login'; // To show login form again
                    break;
                }
                $password = $_POST['password'] ?? '';
                $confirmPassword = $_POST['confirm_password'] ?? '';
                if ($password && $password === $confirmPassword) {
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    if (file_put_contents(PASSWORD_FILE, $hashedPassword) !== false) {
                        header('Location: index.php?action=login');
                        exit;
                    } else {
                        $error = '错误：无法保存密码。请检查服务器权限或磁盘空间。';
                        $_GET['action'] = 'login'; // To show login form again
                    }
                } else {
                    $error = '两次输入的密码不一致或密码为空';
                    $_GET['action'] = 'login'; // To show login form again
                }
                break;
                
            case 'manual_backup':
                // 手动备份功能
                if (isAuthenticated()) {
                    $backupFile = createBackup();
                    if ($backupFile) {
                        $error = '数据库备份成功: ' . basename($backupFile);
                    } else {
                        $error = '数据库备份失败，请检查服务器权限或磁盘空间';
                    }
                }
                break;
        }
    }
}

// ===================================================================
// GET Request Handling & Data Fetching
// ===================================================================
$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;
$tag_filter = $_GET['tag'] ?? null;
$search_query = ($action === 'search') ? ($_GET['q'] ?? '') : null;

$note = getNoteById($id);
$passwordSet = getPassword() !== '';

// Logic for list view (list, search, default)
if ($action === 'list' || $action === 'search' || !in_array($action, ['login', 'edit', 'create', 'view', 'print', 'export_md'])) {
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    if ($page < 1) $page = 1;
    $total_notes = getNotesCount($tag_filter, $search_query);
    $total_pages = ceil($total_notes / NOTES_PER_PAGE);
    if ($page > $total_pages && $total_pages > 0) $page = $total_pages;
    $offset = ($page - 1) * NOTES_PER_PAGE;
    $paginated_notes = getNotes($tag_filter, $search_query, NOTES_PER_PAGE, $offset);
    $unique_tags = getAllTags();
}

// ===================================================================
// Routing & View Loading
// ===================================================================

// Handle actions that require authentication
if (($action === 'edit' || $action === 'create') && !isAuthenticated()) {
    header('Location: index.php?action=login');
    exit;
}

// Handle actions that are standalone pages or have no view
if ($action === 'export_md' && $note) {
    header('Content-Type: text/markdown; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . (empty($note['title']) ? 'note_' . $note['id'] : preg_replace('/[^a-zA-Z0-9_.-]/', '_', $note['title'])) . '.md"');
    echo $note['content'];
    exit;
}

// Handle AJAX request for loading more notes
if ($action === 'load_more') {
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    if ($page < 1) $page = 1;
    $offset = ($page - 1) * NOTES_PER_PAGE;
    $notes_to_load = getNotes($tag_filter, $search_query, NOTES_PER_PAGE, $offset);

    foreach ($notes_to_load as $note_item) {
        include 'views/_note_card.php';
    }
    exit; // Important: stop execution to not render the full layout
}

if ($action === 'print' && $note) {
    require_once 'views/print.php';
    exit;
}

// Prepare variables for the main layout
$page_title = '轻量级在线笔记本';
$view_file = '';

switch ($action) {
    case 'login':
        $page_title = '登录';
        $view_file = 'views/login.php';
        break;

    case 'create':
        $page_title = '创建新笔记';
        $view_file = 'views/edit.php';
        break;

    case 'edit':
        if ($note) {
            $page_title = '编辑笔记: ' . htmlspecialchars($note['title']);
            $view_file = 'views/edit.php';
        } else {
            $error = '未找到要编辑的笔记。';
            $view_file = 'views/list.php'; // Fallback to list view
        }
        break;

    case 'view':
        if ($note) {
            $page_title = htmlspecialchars($note['title']);
            $view_file = 'views/view.php';
        } else {
            $error = '未找到要查看的笔记。';
            $view_file = 'views/list.php'; // Fallback to list view
        }
        break;
    
    case 'search':
        $page_title = '搜索结果: ' . htmlspecialchars($search_query);
        $view_file = 'views/list.php';
        break;

    case 'list':
    default:
        $view_file = 'views/list.php';
        break;
}

// Load the main layout which will include the specific view
require_once 'views/layout.php';
