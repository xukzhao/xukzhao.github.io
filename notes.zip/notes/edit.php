<!-- 修改: 调整复选框和文字的布局 -->
<div class="form-group" style="display:flex; align-items:center; margin-bottom: 10px;">
    <div style="display:flex; align-items:center;">
        <input type="checkbox" id="is_private" name="is_private" value="1" <?= !empty($note['is_private']) ? 'checked' : '' ?>>
        <span style="margin-left:5px;">🔒 设为私密（仅自己可见）</span>
    </div>
</div>