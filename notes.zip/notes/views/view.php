<?php
/**
 * 单篇笔记视图 (Single Note View)
 */
?>
<a href="index.php" class="back-link">← 返回首页</a>
<div class="note-content">
    <?php if (!empty(trim($note['title'] ?? ''))): ?>
        <h1>
            <?= htmlspecialchars($note['title'] ?? '') ?>
            <?php if (!empty($note['is_private'])): ?>
                <span title="私密笔记">🔒</span>
            <?php endif; ?>
        </h1>
    <?php elseif (!empty($note['is_private'])): ?>
        <h1>私密笔记 <span title="私密笔记">🔒</span></h1>
    <?php endif; ?>
    <div class="meta">更新于: <?= $note['updated_at'] ?></div>
    <div class="toastui-editor-contents"><?= parseMarkdown($note['content']) ?></div>
    <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee;">
        <?php if (isAuthenticated()): ?>
            <a href="?action=edit&id=<?= $note['id'] ?>" class="btn btn-secondary">编辑</a>
            <form method="POST" style="display: inline;">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= $note['id'] ?>">
                <button type="submit" class="btn btn-danger" onclick="return confirm('确定要删除这个笔记吗？')">删除</button>
            </form>
            <a href="?action=export_md&id=<?= $note['id'] ?>" class="btn btn-secondary">导出 Markdown</a>
            
        <?php endif; ?>
    </div>
</div>