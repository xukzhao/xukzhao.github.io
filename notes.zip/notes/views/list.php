<?php
/**
 * 笔记列表主视图 (Main Note List View)
 */
?>
<div style="margin-bottom: 20px;">
    <form action="index.php" method="GET" style="display: flex; gap: 10px;">
        <input type="hidden" name="action" value="search">
        <input type="text" name="q" placeholder="搜索笔记..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" style="flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
        <button type="submit" class="btn btn-secondary">搜索</button>
    </form>
    <?php if (isset($_GET['action']) && $_GET['action'] === 'search' && isset($_GET['q'])): ?>
        <div style="margin-top: 10px; padding: 10px; background: #e3f2fd; border-radius: 4px;">
            搜索 "<?= htmlspecialchars($_GET['q']) ?>" 找到 <?= $total_notes ?> 条结果
            <?php if ($total_notes >= MAX_SEARCH_RESULTS): ?>
                <br><small>结果数量较多，建议使用更精确的关键词进行搜索</small>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php if (!empty($unique_tags)): ?>
    <div style="margin-bottom: 20px; padding: 10px; background: #f0f0f0; border-radius: 8px;">
        <strong>标签:</strong>
        <?php foreach ($unique_tags as $tag): ?>
            <a href="?tag=<?= urlencode($tag) ?>" style="display: inline-block; background: #ddd; color: #333; padding: 2px 8px; border-radius: 4px; margin: 2px; text-decoration: none;"><?= htmlspecialchars($tag) ?></a>
        <?php endforeach; ?>
        <?php if (isset($_GET['tag'])): // Show clear filter only if a tag is selected ?>
            <a href="index.php" style="margin-left: 10px; font-size: 0.9em; color: #f44336;">(清除筛选)</a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
    <div>
        <a href="?action=create" class="btn btn-primary">➕ 新建笔记</a>
        <?php if (isAuthenticated()): ?>
            <form method="POST" style="display: inline;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><button type="submit" class="btn btn-secondary">🔒 登出</button></form>
            <form method="POST" style="display: inline;"><input type="hidden" name="action" value="manual_backup"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><button type="submit" class="btn btn-secondary" onclick="return confirm('确定要创建数据库备份吗？')">💾 备份</button></form>
        <?php else: ?>
            <a href="?action=login" class="btn btn-secondary">🔑 登录</a>
        <?php endif; ?>
    </div>
    <div>
        <button id="toggle-dark-mode" class="btn" style="background-color: #607d8b; color: white;">🌙</button>
    </div>
</div>

<!-- Quick add box -->
<div style="background:#eee; border-radius:8px; padding:16px; box-shadow:0 2px 5px rgba(0,0,0,0.1); margin-bottom:20px;">
    <div id="quick-add-wrapper" style="display:flex; gap:12px; align-items:stretch;">
        <div style="flex:1; min-width:0;">
    <form method="POST" id="quick-add-form">
        <input type="hidden" name="action" value="create" />
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>" />
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
            <a href="#" id="toggle-title" style="font-size:0.9rem; color:#2196F3; text-decoration:none;">可选标题 & 标签 ▸</a>
            <span style="font-size:0.85rem; color:#999;"> ESC 清空</span>
        </div>
        <div class="form-group" id="quick-title" style="display:none;">
            <input type="text" name="title" placeholder="可选：标题（不填也可以）" />
        </div>
        <div class="form-group" id="quick-tags" style="display:none;">
            <input type="text" name="tags" placeholder="可选：标签（逗号分隔）" />
        </div>
        <?php if (isAuthenticated()): ?>
        <div class="form-group" id="quick-private" style="display:none;">
            <label for="quick-is-private" class="checkbox-label">
    <input type="checkbox" id="quick-is-private" name="is_private" value="1">
    🔒 设为私密（仅自己可见）
</label>
        </div>
        <?php endif; ?>
        <div class="form-group">
            <textarea name="content" id="quick-content" rows="10" style="width:100%; font-size:1rem;" placeholder="快速记录一些想法，支持 Markdown..."></textarea>
            <div id="quick-char-count" style="font-size: 0.8rem; color: #999; text-align: right; margin-top: 4px;">0 字</div>
        </div>
        <div>
            <button type="submit" class="btn btn-primary">保存</button>
            <button type="button" class="btn btn-secondary" id="quick-clear">清空</button>
        </div>
    </form>
        </div>
        <div style="width:320px; display:none;" id="quick-preview-panel">
            <div style="font-size:0.9rem; color:#666; margin-bottom:6px;">预览</div>
            <div class="toastui-editor-contents" id="quick-preview" style="max-height:360px; overflow:auto; border:1px solid #eee; border-radius:6px; padding:10px;"></div>
        </div>
    </div>
</div>
<div id="notes-list" style="display: flex; flex-direction: column; gap: 15px;">
    <?php if (count($paginated_notes) > 0): ?>
        <?php foreach ($paginated_notes as $note_item): ?>
            <?php include 'views/_note_card.php'; ?>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="background:white; border-radius:8px; padding:20px; text-align:center;">
            <h2>还没有笔记</h2>
            <p>点击"新建笔记"按钮创建你的第一条笔记。</p>
        </div>
    <?php endif; ?>
</div>

<!-- Load More Button -->
<?php if ($total_pages > 1): ?>
<div id="load-more-container" style="margin-top: 20px; text-align: center;">
    <button id="load-more-btn" class="btn btn-primary" data-current-page="1" data-total-pages="<?= $total_pages ?>">加载更多</button>
</div>
<?php endif; ?>

<!-- 搜索结果统计 -->
<?php if ($search_query): ?>
<div style="margin-top: 20px; padding: 10px; background: #e3f2fd; border-radius: 4px; text-align: center;">
    搜索"<?= htmlspecialchars($search_query) ?>"找到 <?= $total_notes ?> 条结果
    <?php if ($total_notes > 50): ?>
        <div style="font-size: 0.9em; margin-top: 5px;">提示：搜索结果较多，建议使用更精确的关键词</div>
    <?php endif; ?>
</div>
<?php endif; ?>