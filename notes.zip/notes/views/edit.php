<?php
/**
 * 编辑/创建视图 (Edit/Create View)
 */
?>
<a href="index.php" class="back-link">← 返回首页</a>

<form method="POST" id="edit-form">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
    <input type="hidden" name="action" value="<?= ($action === 'create') ? 'create' : 'update' ?>">
    <?php if ($action === 'edit'): ?>
        <input type="hidden" name="id" value="<?= $note['id'] ?>">
        <input type="hidden" name="version" value="<?= htmlspecialchars($note['version'] ?? 1) ?>">
    <?php endif; ?>
    <div style="margin-bottom:10px;">
        <a href="#" id="form-toggle-title" style="font-size:0.9rem; color:#2196F3; text-decoration:none;">可选标题 & 标签 ▸</a>
    </div>
    <div class="form-group" id="form-title" style="display:none;">
        <label for="title">标题（可选）:</label>
        <input type="text" id="title" name="title" value="<?= htmlspecialchars($note['title'] ?? '') ?>">
    </div>
    <div class="form-group" id="form-tags" style="display:none;">
        <label for="tags">标签（逗号分隔）:</label>
        <input type="text" id="tags" name="tags" value="<?= htmlspecialchars(implode(', ', $note['tags'] ?? [])) ?>">
    </div>
    <div style="margin-bottom: 10px;">
        <label for="is_private">
            <input type="checkbox" id="is_private" name="is_private" value="1" <?= !empty($note['is_private']) ? 'checked' : '' ?>>
            🔒 设为私密（仅自己可见）
        </label>
    </div>
    <div class="form-group">
        <div id="editor"></div>
        <textarea name="content" id="content" placeholder="如果编辑器加载失败，会显示此输入框。"><?php if (!empty($note['content'])) echo htmlspecialchars($note['content']); ?></textarea>
    </div>
    
    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <button type="submit" class="btn btn-primary"><?= ($action === 'create') ? '保存笔记' : '更新笔记' ?></button>
        <a href="index.php" class="btn btn-secondary">取消</a>
        <button type="button" id="clear-content" class="btn btn-danger">清空内容</button>
    </div>
</form>
<script>
// 在编辑器初始化前先应用主题
document.addEventListener('DOMContentLoaded', function() {
    // 确保主题已正确应用
    try {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            const body = document.body;
            const themeToggleBtn = document.getElementById('toggle-dark-mode');
            
            if (savedTheme === 'dark') {
                body.classList.add('dark-mode');
                if (themeToggleBtn) themeToggleBtn.textContent = '☀️';
            } else {
                body.classList.remove('dark-mode');
                if (themeToggleBtn) themeToggleBtn.textContent = '🌙';
            }
        }
    } catch (e) {
        console.error('应用初始主题时出错:', e);
    }
    
    const indicator = document.getElementById('autosave-indicator');
    if (indicator) {
        indicator.style.display = 'block';
    }
    
    // 添加ESC键清空内容功能
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const content = document.getElementById('content');
            if (content && document.activeElement === content) {
                if (confirm('确定要清空所有内容吗？')) {
                    content.value = '';
                    // 如果使用了编辑器，也需要清空编辑器内容
                    const editorEl = document.getElementById('editor');
                    if (window.editor && editorEl && editorEl.children.length > 0) {
                        window.editor.setMarkdown('');
                    }
                }
            }
        }
    });
    
    // 添加清空内容按钮功能
    const clearBtn = document.getElementById('clear-content');
    if (clearBtn) {
        clearBtn.addEventListener('click', function() {
            if (confirm('确定要清空所有内容吗？')) {
                const content = document.getElementById('content');
                if (content) {
                    content.value = '';
                }
                
                // 如果使用了编辑器，也需要清空编辑器内容
                const editorEl = document.getElementById('editor');
                if (window.editor && editorEl && editorEl.children.length > 0) {
                    window.editor.setMarkdown('');
                }
                
                // 清空标题和标签
                const title = document.getElementById('title');
                const tags = document.getElementById('tags');
                if (title) title.value = '';
                if (tags) tags.value = '';
            }
        });
    }
});
</script>