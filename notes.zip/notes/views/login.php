<?php
/**
 * 登录视图 (Login View)
 */
?>
<div style="background:white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
    <h1>🔒 登录</h1>
    <?php if (!$passwordSet): ?>
        <p>首次使用，请设置密码：</p>
        <form method="POST">
            <input type="hidden" name="action" value="set_password">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            <div class="form-group"><label for="password">新密码:</label><input type="password" id="password" name="password" required></div>
            <div class="form-group"><label for="confirm_password">确认密码:</label><input type="password" id="confirm_password" name="confirm_password" required></div>
            <button type="submit" class="btn btn-primary" style="width:100%;">设置密码</button>
        </form>
    <?php else: ?>
        <form method="POST">
            <input type="hidden" name="action" value="login">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            <div class="form-group"><label for="password">密码:</label><input type="password" id="password" name="password" required></div>
            <button type="submit" class="btn btn-primary" style="width:100%;">登录</button>
        </form>
    <?php endif; ?>
    <p style="text-align:center; margin-top:20px;"><a href="index.php">← 返回首页</a></p>
</div>