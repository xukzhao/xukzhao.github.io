<?php
/**
 * 打印视图 (Print View)
 * This is a standalone HTML page.
 */
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($note['title'] ?? '笔记') ?></title>
    <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css" />
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; }
        .toastui-editor-contents { max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #eee; }
        @media print {
            body { margin: 0; }
            .toastui-editor-contents { border: none; padding: 0; }
        }
    </style>
</head>
<body>
    <div class="toastui-editor-contents">
        <?php if (!empty(trim($note['title'] ?? ''))): ?>
            <h1><?= htmlspecialchars($note['title'] ?? '') ?></h1>
        <?php endif; ?>
        <div class="meta">更新于: <?= $note['updated_at'] ?></div>
        <?= parseMarkdown($note['content']) ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/prismjs@1.29.0/components/prism-core.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/prismjs@1.29.0/plugins/autoloader/prism-autoloader.min.js"></script>
    <script>
      Prism.plugins.autoloader.languages_path = 'https://cdn.jsdelivr.net/npm/prismjs@1.29.0/components/';
      document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('pre code').forEach(code => {
          if (!code.className.includes('language-')) {
            code.classList.add('language-markup');
          }
        });
        Prism.highlightAll();
      });
    </script>
</body>
</html>
