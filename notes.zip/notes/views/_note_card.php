<?php
/**
 * Partial view for a single note card.
 * Expects a $note_item variable to be set.
 */
?>
<div class="note-card" style="background:white; border-radius:8px; padding:20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
    <?php if (!empty(trim($note_item['title'] ?? ''))): ?>
        <h2 style="margin-top:0;">
            <?= htmlspecialchars($note_item['title'] ?? '') ?>
            <?php if (!empty($note_item['is_private'])): ?>
                <span title="私密笔记">🔒</span>
            <?php endif; ?>
        </h2>
    <?php elseif (!empty($note_item['is_private'])): ?>
        <h2 style="margin-top:0;">
            私密笔记 <span title="私密笔记">🔒</span>
        </h2>
    <?php endif; ?>
    <p style="font-size:0.8rem; color:#999;">创建于: <?= $note_item['created_at'] ?> | 更新于: <?= $note_item['updated_at'] ?></p>
    <?php if (!empty($note_item['tags'])): ?>
        <div style="margin-top: 8px; margin-bottom: 8px;">
            <?php foreach ($note_item['tags'] as $tag): ?>
                <a href="?tag=<?= urlencode($tag) ?>" style="display: inline-block; background: #e0e0e0; color: #555; padding: 2px 8px; border-radius: 4px; margin-right: 5px; text-decoration: none; font-size: 0.8rem;"><?= htmlspecialchars($tag) ?></a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <div class="note-body">
        <?php
            $content = $note_item['content'];
            $full_content_html = parseMarkdown($content);
            
            // Define a threshold for long content
            $is_long_content = (function_exists('mb_strlen') ? mb_strlen($content, 'UTF-8') : strlen($content)) > 250;

            if ($is_long_content) {
                // Create a summary
                $summary_content = $content;
                $parts = preg_split('/\R{2,}/', $summary_content, 2);
                $firstBlock = $parts[0] ?? $summary_content;
                $len = function_exists('mb_strlen') ? mb_strlen($firstBlock, 'UTF-8') : strlen($firstBlock);
                if ($len > 200) {
                    $firstBlock = (function_exists('mb_substr') ? mb_substr($firstBlock, 0, 200, 'UTF-8') : substr($firstBlock, 0, 200)) . '…';
                }
                $summary_html = parseMarkdown($firstBlock);

                echo '<div class="note-content-summary toastui-editor-contents">' . $summary_html . '</div>';
                echo '<div class="note-content-full toastui-editor-contents" style="display: none;">' . $full_content_html . '</div>';
                echo '<button class="btn-toggle-content">更多</button>';
            } else {
                // Render only full content if it's short
                echo '<div class="toastui-editor-contents">' . $full_content_html . '</div>';
            }
        ?>
    </div>
    <div class="card-actions-wrapper">
        <button class="card-menu-toggle" aria-label="更多操作">⋮</button>
        <div class="card-actions-menu">
            <a href="?action=view&id=<?= $note_item['id'] ?>" class="card-menu-item">
                <span class="icon">👁️</span>
                <span class="text">查看</span>
            </a>
            <?php if (isAuthenticated()): ?>
                <a href="?action=edit&id=<?= $note_item['id'] ?>" class="card-menu-item">
                    <span class="icon">✏️</span>
                    <span class="text">编辑</span>
                </a>
                <form method="POST" action="index.php" onsubmit="return confirm('确定要删除这个笔记吗？');" class="card-menu-item">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $note_item['id'] ?>">
                    <button type="submit">
                        <span class="icon">🗑️</span>
                        <span class="text">删除</span>
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>