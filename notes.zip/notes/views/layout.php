<?php
/**
 * 主布局文件 (Main Layout File)
 * 定义了所有页面的通用头部和尾部信息。
 */
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? '轻量级在线笔记本' ?></title>
    
    <script>
        (function() {
            try {
                const savedTheme = localStorage.getItem('theme');
                if (savedTheme === 'dark') {
                    document.documentElement.classList.add('dark-mode');
                } else if (!savedTheme && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    document.documentElement.classList.add('dark-mode');
                }
            } catch (e) {
                console.error('Error applying initial theme:', e);
            }
        })();
    </script>

    <!-- External CSS -->
    <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.29.0/themes/prism.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.29.0/plugins/toolbar/prism-toolbar.css" />
    
    <!-- Local styles -->
    <link rel="stylesheet" href="assets/style.css?v=<?= @filemtime('assets/style.css') ?: time() ?>" />
</head>
<body>
    <div class="container">
        <header>
            <h1>📝 轻量级在线笔记本</h1>
        </header>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php 
        // 包含由控制器指定的核心视图文件
        if (!empty($view_file) && file_exists($view_file)) {
            require_once $view_file;
        } else {
            echo '<div class="error-message">错误：无法加载视图文件。</div>';
        }
        ?>

    </div>

    <!-- External Scripts -->
    <script src="https://uicdn.toast.com/editor/latest/toastui-editor-all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/prismjs@1.29.0/components/prism-core.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/prismjs@1.29.0/plugins/autoloader/prism-autoloader.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/dompurify/dist/purify.min.js"></script>
    
    <!-- Local App Scripts -->
    <script>
        // 将PHP数据安全地传递给JavaScript
        window.appData = {
            noteContent: <?= json_encode($note['content'] ?? '', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
            csrfToken: <?= json_encode($_SESSION['csrf_token'] ?? '') ?>,
        };
        
        // 全局错误处理
        window.addEventListener('error', function(e) {
            console.error('全局错误:', e.error);
        });
        
        // Promise错误处理
        window.addEventListener('unhandledrejection', function(e) {
            console.error('未处理的Promise错误:', e.reason);
        });
        
        // 添加页面加载完成事件
        document.addEventListener('DOMContentLoaded', function() {
            console.log('页面加载完成');
        });
    </script>
    <a href="#" id="back-to-top" title="回到顶部">⬆️</a>
    <script src="assets/main.js?v=<?= filemtime('assets/main.js') ?>"></script>
</body>
</html>