// =================================================================
// 1. Utility Functions
// =================================================================

/**
 * Utility function to enhance markdown content with additional features.
 * @param {HTMLElement} element - The element to enhance.
 */
function enhanceMarkdownContent(element) {
    if (!element) return;
    
    try {
        // Add copy buttons to code blocks
        element.querySelectorAll('pre code').forEach(code => {
            if (!code.closest('.toastui-editor-contents')) return; // Skip editor's own code blocks
            
            const pre = code.parentElement;
            if (!pre || pre.querySelector('.code-copy-btn')) return; // Skip if button already exists
            
            const button = document.createElement('button');
            button.className = 'code-copy-btn';
            button.textContent = '📋';
            button.title = '复制代码';
            
            button.addEventListener('click', () => {
                navigator.clipboard.writeText(code.textContent).then(() => {
                    const originalText = button.textContent;
                    button.textContent = '✅';
                    setTimeout(() => {
                        button.textContent = originalText;
                    }, 2000);
                }).catch(err => {
                    console.error('复制失败:', err);
                    button.textContent = '❌';
                    setTimeout(() => {
                        button.textContent = '📋';
                    }, 2000);
                });
            });
            
            pre.style.position = 'relative';
            pre.appendChild(button);
        });
    } catch (e) {
        console.error('增强Markdown内容时出错:', e);
    }
}

/**
 * Utility function to enhance note cards with interactive features.
 * @param {HTMLElement} card - The note card element to enhance.
 */
function enhanceNoteCard(card) {
    if (!card || !card.classList.contains('note-card')) return;
    
    try {
        // Enhance markdown content within the card
        const contentElements = card.querySelectorAll('.toastui-editor-contents');
        contentElements.forEach(enhanceMarkdownContent);
    } catch (e) {
        console.error('增强笔记卡片时出错:', e);
    }
}

/**
 * Utility function to initialize content toggle functionality.
 * @param {HTMLElement} container - The container element to initialize.
 */
function initContentToggle(container) {
    if (!container) return;
    
    try {
        const toggleButtons = container.querySelectorAll('.btn-toggle-content');
        toggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                const summary = button.previousElementSibling.previousElementSibling;
                const fullContent = button.previousElementSibling;
                
                if (summary && fullContent) {
                    const isExpanded = summary.style.display === 'none';
                    summary.style.display = isExpanded ? 'block' : 'none';
                    fullContent.style.display = isExpanded ? 'none' : 'block';
                    button.textContent = isExpanded ? '更多' : '收起';
                }
            });
        });
    } catch (e) {
        console.error('初始化内容切换功能时出错:', e);
    }
}

// =================================================================
// 2. Feature Initializers
// =================================================================

/**
 * Adds the event listener for the theme toggle button.
 */
function addThemeToggleListener() {
    try {
        const themeToggleBtn = document.getElementById('toggle-dark-mode');
        if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', function() {
                const isDark = document.documentElement.classList.contains('dark-mode');
                const newTheme = isDark ? 'light' : 'dark';
                applyTheme(newTheme);
            });
        }
    } catch (e) {
        console.error('添加主题切换监听器时出错:', e);
    }
}

/**
 * Applies the initial theme based on localStorage or system preference.
 */
function applyInitialTheme() {
    try {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            applyTheme(savedTheme);
        } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            applyTheme('dark');
        } else {
            applyTheme('light'); // Default to light theme
        }
    } catch (e) {
        console.error('应用初始主题时出错:', e);
        applyTheme('light'); // Fallback to light theme
    }
}

/**
 * Applies the theme to the document.
 * @param {string} theme - The theme to apply ('light' or 'dark').
 */
function applyTheme(theme) {
    try {
        const themeToggleBtn = document.getElementById('toggle-dark-mode');
        
        if (theme === 'dark') {
            document.documentElement.classList.add('dark-mode');
            if (themeToggleBtn) themeToggleBtn.textContent = '☀️';
        } else {
            document.documentElement.classList.remove('dark-mode');
            if (themeToggleBtn) themeToggleBtn.textContent = '🌙';
        }
        
        // 保存主题设置到localStorage
        localStorage.setItem('theme', theme);
    } catch (e) {
        console.error('应用主题时出错:', e);
    }
}

/**
 * Initializes infinite scrolling for loading more notes.
 */
function initLoadMoreButton() {
    try {
        const loadMoreContainer = document.getElementById('load-more-container');
        if (!loadMoreContainer) return;

        const loadMoreBtn = document.getElementById('load-more-btn'); // We still need the button for state

        const observer = new IntersectionObserver(async (entries) => {
            // Check if the trigger element is intersecting and we are not already loading
            if (entries[0].isIntersecting && !loadMoreBtn.disabled) {
                const currentPage = parseInt(loadMoreBtn.dataset.currentPage, 10) + 1;
                const totalPages = parseInt(loadMoreBtn.dataset.totalPages, 10);

                if (currentPage > totalPages) {
                    loadMoreContainer.style.display = 'none';
                    observer.disconnect(); // All pages loaded, stop observing
                    return;
                }

                const notesList = document.getElementById('notes-list');
                loadMoreBtn.disabled = true;
                loadMoreBtn.textContent = '正在加载...';

                try {
                    const urlParams = new URLSearchParams(window.location.search);
                    urlParams.set('action', 'load_more');
                    urlParams.set('page', currentPage);
                    const url = `index.php?${urlParams.toString()}`;

                    const response = await fetch(url);
                    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

                    const newNotesHtml = await response.text();
                    if (!newNotesHtml.trim()) {
                        loadMoreContainer.style.display = 'none';
                        observer.disconnect(); // No more content, stop observing
                        return;
                    }

                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = newNotesHtml;

                    Array.from(tempDiv.children).forEach(newCard => {
                        notesList.appendChild(newCard);
                        enhanceNoteCard(newCard);
                        initContentToggle(newCard);
                    });

                    loadMoreBtn.dataset.currentPage = currentPage;

                } catch (error) {
                    console.error("加载更多失败:", error);
                    loadMoreBtn.textContent = '加载失败，请重试';
                    // 显示错误信息给用户
                    const errorMsg = document.createElement('div');
                    errorMsg.className = 'error-message';
                    errorMsg.textContent = '加载更多笔记失败: ' + error.message;
                    loadMoreContainer.parentNode.insertBefore(errorMsg, loadMoreContainer.nextSibling);
                    setTimeout(() => {
                        errorMsg.remove();
                    }, 5000);
                } finally {
                    if (currentPage < totalPages) {
                        loadMoreBtn.disabled = false;
                        loadMoreBtn.textContent = '滚动加载更多'; // Reset button text
                    } else {
                        loadMoreContainer.style.display = 'none';
                        observer.disconnect(); // All pages loaded, stop observing
                    }
                }
            }
        }, {
            rootMargin: '200px', // Start loading 200px before the element is in view
            threshold: 0.1
        });

        // Start observing the container
        observer.observe(loadMoreContainer);
        loadMoreBtn.textContent = '滚动加载更多'; // Update initial text
    } catch (e) {
        console.error('初始化加载更多按钮时出错:', e);
    }
}

/**
 * Initializes the ToastUI editor if it exists on the page.
 */
function initEditor() {
    try {
        // 确保主题已正确应用
        applyInitialTheme();
        
        const editorEl = document.getElementById('editor');
        const textarea = document.getElementById('content');
        const form = document.getElementById('edit-form');
        const titleInput = document.getElementById('title');
        const tagsInput = document.getElementById('tags');
        const privateCheckbox = document.getElementById('is_private');

        // Optional title toggle in edit form
        const toggleTitleLink = document.getElementById('form-toggle-title');
        const titleGroup = document.getElementById('form-title');
        if (toggleTitleLink && titleGroup) {
            toggleTitleLink.addEventListener('click', (e) => {
                e.preventDefault();
                const isHidden = titleGroup.style.display === 'none' || getComputedStyle(titleGroup).display === 'none';
                titleGroup.style.display = isHidden ? 'block' : 'none';
                const tagsGroup = document.getElementById('form-tags'); // Get the tags group
                if (tagsGroup) { // Check if it exists
                    tagsGroup.style.display = isHidden ? 'block' : 'none'; // Toggle its display
                }
                toggleTitleLink.textContent = isHidden ? '可选标题 & 标签 ▾' : '可选标题 & 标签 ▸';
            });
        }

        // Auto-save functionality for edit form
        let autosaveInterval;
        if (form) {
            // Generate a unique key for this note based on the current URL
            const autosaveKey = 'autosave_edit_' + window.location.search;
            
            // Load autosaved content if available
            const savedData = localStorage.getItem(autosaveKey);
            if (savedData) {
                try {
                    const data = JSON.parse(savedData);
                    if (titleInput && data.title !== undefined) titleInput.value = data.title;
                    if (textarea && data.content !== undefined) textarea.value = data.content;
                    if (tagsInput && data.tags !== undefined) tagsInput.value = data.tags;
                    if (privateCheckbox && data.is_private !== undefined) privateCheckbox.checked = data.is_private;
                } catch (e) {
                    console.error('Failed to load autosaved data:', e);
                }
            }
            
            // Save form data periodically
            const saveFormData = () => {
                const data = {
                    title: titleInput ? titleInput.value : '',
                    content: textarea ? textarea.value : '',
                    tags: tagsInput ? tagsInput.value : '',
                    is_private: privateCheckbox ? privateCheckbox.checked : false,
                    timestamp: Date.now()
                };
                localStorage.setItem(autosaveKey, JSON.stringify(data));
                
                // Show autosave indicator
                const indicator = document.getElementById('autosave-indicator');
                if (indicator) {
                    indicator.style.display = 'block';
                    setTimeout(() => {
                        indicator.style.opacity = '1';
                        setTimeout(() => {
                            indicator.style.opacity = '0.8';
                        }, 2000);
                    }, 100);
                }
            };
            
            // Set up autosave interval (every 5 seconds)
            if (titleInput) titleInput.addEventListener('input', saveFormData);
            if (textarea) textarea.addEventListener('input', saveFormData);
            if (tagsInput) tagsInput.addEventListener('input', saveFormData);
            if (privateCheckbox) privateCheckbox.addEventListener('change', saveFormData);
            
            // Clear autosaved data on successful form submission
            form.addEventListener('submit', () => {
                localStorage.removeItem(autosaveKey);
                
                // Hide autosave indicator
                const indicator = document.getElementById('autosave-indicator');
                if (indicator) {
                    indicator.style.display = 'none';
                }
            });
            
            // Set up periodic autosave (every 5 seconds)
            autosaveInterval = setInterval(saveFormData, 5000);
        }

        if (!editorEl || !textarea) return;

        // Fallback if Toast UI Editor is not available
        if (typeof toastui === 'undefined' || !toastui.Editor) {
            editorEl.style.display = 'none';
            textarea.style.display = 'block';
            if (window.appData && typeof window.appData.noteContent === 'string') {
                textarea.value = window.appData.noteContent;
            }
            return;
        }

        try {
            // 确保主题已正确应用
            applyInitialTheme();
            
            const initialValue = (window.appData && typeof window.appData.noteContent === 'string')
                ? window.appData.noteContent
                : (textarea.value || '');

            // Hide the textarea when rich editor is available
            textarea.style.display = 'none';

            const editor = new toastui.Editor({
                el: editorEl,
                height: '600px',
                initialEditType: 'wysiwyg',
                previewStyle: 'vertical',
                usageStatistics: false,
                autofocus: true,
                placeholder: '在此输入内容',
                toolbarItems: [
                    ['heading', 'bold', 'italic', 'strike'],
                    ['hr', 'quote'],
                    ['ul', 'ol', 'task'],
                    ['table', 'link', 'code', 'codeblock']
                ]
            });

            editor.setMarkdown(initialValue);
            
            // 强制应用暗色主题到编辑器容器
            const applyEditorTheme = () => {
                const isDark = document.documentElement.classList.contains('dark-mode');
                if (isDark) {
                    editorEl.classList.add('dark-mode-applied');
                } else {
                    editorEl.classList.remove('dark-mode-applied');
                }
                
                // 强制更新编辑器预览区域的主题
                const preview = editorEl.querySelector('.toastui-editor-preview');
                if (preview) {
                    if (isDark) {
                        preview.classList.add('toastui-editor-dark');
                    } else {
                        preview.classList.remove('toastui-editor-dark');
                    }
                }
            };
            
            // 初始应用主题
            applyEditorTheme();
            
            // 添加主题切换观察器
            const themeToggleBtn = document.getElementById('toggle-dark-mode');
            if (themeToggleBtn) {
                themeToggleBtn.addEventListener('click', () => {
                    setTimeout(applyEditorTheme, 100); // 延迟确保主题切换完成
                });
            }
            
            // 添加窗口主题变化监听器
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
                applyInitialTheme(); // 应用新的系统主题
                applyEditorTheme(); // 更新编辑器主题
            });

            // Add autosave for ToastUI Editor
            if (form && editor) {
                // Generate a unique key for this note based on the current URL
                const autosaveKey = 'autosave_edit_' + window.location.search;
                
                // Load autosaved content if available for editor
                const savedData = localStorage.getItem(autosaveKey);
                if (savedData) {
                    try {
                        const data = JSON.parse(savedData);
                        if (data.content !== undefined) {
                            editor.setMarkdown(data.content);
                        }
                    } catch (e) {
                        console.error('Failed to load autosaved data for editor:', e);
                    }
                }
                
                // Autosave editor content
                const saveEditorData = () => {
                    const data = {
                        title: titleInput ? titleInput.value : '',
                        content: editor.getMarkdown(),
                        tags: tagsInput ? tagsInput.value : '',
                        is_private: privateCheckbox ? privateCheckbox.checked : false,
                        timestamp: Date.now()
                    };
                    localStorage.setItem(autosaveKey, JSON.stringify(data));
                    
                    // Show autosave indicator
                    const indicator = document.getElementById('autosave-indicator');
                    if (indicator) {
                        indicator.style.display = 'block';
                        setTimeout(() => {
                            indicator.style.opacity = '1';
                            setTimeout(() => {
                                indicator.style.opacity = '0.8';
                            }, 2000);
                        }, 100);
                    }
                };
                
                // Set up editor autosave
                editor.on('change', saveEditorData);
                
                // Also periodically save (every 5 seconds)
                if (autosaveInterval) {
                    clearInterval(autosaveInterval);
                }
                autosaveInterval = setInterval(saveEditorData, 5000);
            }

            if (form) {
                form.addEventListener('submit', () => {
                    if (editor) {
                        textarea.value = editor.getMarkdown();
                    }
                    
                    // Clear autosaved data on successful form submission
                    const autosaveKey = 'autosave_edit_' + window.location.search;
                    localStorage.removeItem(autosaveKey);
                    
                    // Hide autosave indicator
                    const indicator = document.getElementById('autosave-indicator');
                    if (indicator) {
                        indicator.style.display = 'none';
                    }
                });
            }
            
            // 将editor实例保存到全局变量，以便其他函数可以访问
            window.editor = editor;
        } catch (e) {
            console.error('Failed to initialize ToastUI Editor:', e);
            // Fallback to textarea if editor fails to initialize
            editorEl.style.display = 'none';
            textarea.style.display = 'block';
            if (window.appData && typeof window.appData.noteContent === 'string') {
                textarea.value = window.appData.noteContent;
            }
        }
    } catch (e) {
        console.error('初始化编辑器时出错:', e);
    }
}

/**
 * Initializes the Quick Add form functionality.
 */
function initQuickAddForm() {
    try {
        const form = document.getElementById('quick-add-form');
        if (!form) return;

        const quickContent = document.getElementById('quick-content');
        const quickPreview = document.getElementById('quick-preview');
        const quickPreviewPanel = document.getElementById('quick-preview-panel');
        const quickClearBtn = document.getElementById('quick-clear');
        const quickCharCount = document.getElementById('quick-char-count');

        // Toggle extra fields
        const toggleTitle = document.getElementById('toggle-title');
        const quickTitle = document.getElementById('quick-title');
        const quickTags = document.getElementById('quick-tags');
        const quickPrivate = document.getElementById('quick-private');
        if (toggleTitle) {
            toggleTitle.addEventListener('click', (e) => {
                e.preventDefault();
                const hidden = quickTitle.style.display === 'none' || getComputedStyle(quickTitle).display === 'none';
                const newDisplay = hidden ? 'block' : 'none';
                quickTitle.style.display = newDisplay;
                quickTags.style.display = newDisplay;
                if (quickPrivate) quickPrivate.style.display = newDisplay;
                toggleTitle.textContent = hidden ? '可选标题 & 标签 ▾' : '可选标题 & 标签 ▸';
            });
        }

        // Live preview (use marked + DOMPurify if available)
        function renderPreview(md) {
            if (!quickPreview || !quickPreviewPanel) return;
            if (!md.trim()) {
                quickPreviewPanel.style.display = 'none';
                quickPreview.innerHTML = '';
                return;
            }
            // quickPreviewPanel.style.display = 'block';
            if (window.DOMPurify && window.marked) {
                try {
                    const html = window.DOMPurify.sanitize(window.marked.parse(md));
                    quickPreview.innerHTML = html;
                } catch (e) {
                    console.error('Markdown解析错误:', e);
                    quickPreview.textContent = md;
                }
            } else {
                quickPreview.textContent = md;
            }
        }

        function updateCharCount() {
            if (!quickCharCount) return;
            const len = quickContent.value.length;
            quickCharCount.textContent = `${len} 字`;
        }

        quickContent.addEventListener('input', () => {
            try {
                renderPreview(quickContent.value);
                updateCharCount();
            } catch (e) {
                console.error('更新预览失败:', e);
            }
        });

        // Clear button
        if (quickClearBtn) {
            quickClearBtn.addEventListener('click', () => {
                try {
                    quickContent.value = '';
                    renderPreview('');
                    updateCharCount();
                } catch (e) {
                    console.error('清空内容失败:', e);
                }
            });
        }

        // Ctrl/Cmd + Enter to submit
        quickContent.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                try {
                    form.requestSubmit();
                } catch (e) {
                    console.error('提交表单失败:', e);
                }
            }
        });

        // ESC to clear
        quickContent.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                try {
                    quickContent.value = '';
                    renderPreview('');
                    updateCharCount();
                } catch (e) {
                    console.error('清空内容失败:', e);
                }
            }
        });

        // Initial render
        try {
            renderPreview(quickContent.value);
            updateCharCount();
        } catch (e) {
            console.error('初始化预览失败:', e);
        }
        
        // 表单提交处理
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = '保存中...';
            submitBtn.disabled = true;
            
            try {
                const formData = new FormData(form);
                const response = await fetch('index.php', {
                    method: 'POST',
                    body: formData
                });
                
                if (response.ok) {
                    // 成功后重新加载页面
                    window.location.reload();
                } else {
                    throw new Error('保存失败，HTTP状态码: ' + response.status);
                }
            } catch (error) {
                console.error('保存失败:', error);
                alert('保存失败: ' + error.message);
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }
        });
    } catch (e) {
        console.error('初始化快速添加表单时出错:', e);
    }
}

/**
 * Initializes the Back to Top button functionality.
 */
function initBackToTopButton() {
    try {
        const backToTopBtn = document.getElementById('back-to-top');
        if (!backToTopBtn) return;

        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopBtn.style.display = 'block';
            } else {
                backToTopBtn.style.display = 'none';
            }
        });

        backToTopBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    } catch (e) {
        console.error('初始化回到顶部按钮时出错:', e);
    }
}

// =================================================================
// 3. Main Execution
// =================================================================

// Apply global enhancements to any existing static content
document.querySelectorAll('.toastui-editor-contents').forEach(enhanceMarkdownContent);

// Enhance all initial note cards
document.querySelectorAll('.note-card').forEach(enhanceNoteCard);
initContentToggle(document); // Initialize for all existing cards

// Initialize all features
addThemeToggleListener();
initLoadMoreButton();
initEditor();
initQuickAddForm();
initBackToTopButton();

// Initialize Prism.js for syntax highlighting if available
if (typeof Prism !== 'undefined') {
    try {
        Prism.plugins.autoloader.languages_path = 'https://cdn.jsdelivr.net/npm/prismjs@1.29.0/components/';
        Prism.highlightAll();
    } catch (e) {
        console.error('初始化代码高亮时出错:', e);
    }
}

// =================================================================
// 4. Card Actions Menu
// =================================================================

function initCardActionMenus() {
    try {
        const noteList = document.getElementById('notes-list');
        if (!noteList) return;

        // Use event delegation to handle clicks on all menu toggles
        noteList.addEventListener('click', (event) => {
            const toggle = event.target.closest('.card-menu-toggle');
            if (!toggle) return;

            const wrapper = toggle.closest('.card-actions-wrapper');
            if (!wrapper) return;

            // Close all other open menus
            document.querySelectorAll('.card-actions-wrapper.active').forEach(openWrapper => {
                if (openWrapper !== wrapper) {
                    openWrapper.classList.remove('active');
                }
            });

            // Toggle the current menu
            wrapper.classList.toggle('active');
            event.stopPropagation();
        });

        // Global click listener to close menus when clicking outside
        document.addEventListener('click', (event) => {
            if (!event.target.closest('.card-actions-wrapper')) {
                document.querySelectorAll('.card-actions-wrapper.active').forEach(openWrapper => {
                    openWrapper.classList.remove('active');
                });
            }
        });

    } catch (e) {
        console.error('Initializing card action menus failed:', e);
    }
}

// Initialize menus on DOMContentLoaded
document.addEventListener('DOMContentLoaded', initCardActionMenus);